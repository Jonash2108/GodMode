--Made by Squidbq#3331
--Credit for helping to 'RulyPancake the 5th#1345'

local file_editing = {}

local isenabled = false
local feature = {}
local firsttimeloading = true

function file_editing.write(file, text)
    if file and text then
        io.output(file)
        io.write(text)
        io.close(file)
    end
end

local file = io.open(utils.get_appdata_path("PopstarDevs", "2Take1Menu").."\\scripts\\Godmode\\Settings.ini", "r")
		for line in file:lines() do
			if string.find(line, "Shoot gods = true") then
                isenabled = true
            end
        end


local local_parent = menu.add_feature("Remove Godmode", "parent", 0)

feature["Shoot gods"] = menu.add_feature("Shoot gods", "toggle", local_parent.id, function(f)
    while true do
        isenabled = f.on
        system.yield(0)
        if f.on then
            for pid = 0, 31 do
                if player.is_player_valid(pid) then
                    if pid ~= player.player_id() then
                        if player.is_player_free_aiming(player.player_id()) and player.get_entity_player_is_aiming_at(player.player_id()) == player.get_player_ped(pid) then
                            if player.is_player_god(pid) and interior.get_interior_from_entity(player.get_player_ped(pid)) == 0 then
                                script.trigger_script_event_2(1 << pid, 801199324, player.player_id(), 869796886)
                            end
                        end
                    end
                end
            end
        end
    end
end)

menu.add_feature("Save","action",local_parent.id, function(f)
    file_editing.write(io.open(utils.get_appdata_path("PopstarDevs\\2Take1Menu\\scripts\\Godmode\\", "") .. "\\Settings.ini", "w"), "")
    file_editing.write(io.open(utils.get_appdata_path("PopstarDevs\\2Take1Menu\\scripts\\Godmode\\", "") .. "\\Settings.ini", "a"), "Shoot gods = "..tostring(isenabled))
    menu.notify("Config saved!",nil,5, 0x00FF00)
end)

if firsttimeloading then
    feature["Shoot gods"].on = isenabled
    firsttimeloading = false
    if isenabled then
        menu.notify("Loaded Shoot Gods!\nState: 'ON'",nil,5, 0x00FF00)
    else
        menu.notify("Loaded Shoot Gods!\nState: 'OFF'",nil,5, 0x00FF00)
    end
end